exports.encrypt = function() {

}